var bananaImage, obstaclesImage, jungle, banana, obstacles, monkey;
var obstaclesGroup, foodGroup;
var background1, score;
var background_img;
var player_running;
var ground;

function preload(){
  background_img = loadImage("jungle.jpg");
  player_running = 
loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png" , "Monkey_09.png", "Monkey_10.png");
  
  bananaImage = loadImage("banana.png");
  obstaclesImage = loadImage("stone.png");
}

function setup() {
  createCanvas(600, 600);
  background1 = createSprite(300, 300, 1200, 600);
  background1.addImage(background_img);
  background1.velocityX=-2
  background1.scale=1.2
  monkey=createSprite(100,500,10,10)
  monkey.addAnimation("running",player_running)
  monkey.scale=.2
  ground=createSprite(300,500,1200,10)
  ground.velocityX=-2
  ground.x=ground.width/2
}
function draw() {
  background(220);
  if(background1.x<0){
    background1.x=background1.width/2
  }
  /*if(foodGroup.istouching(monkey)){
    score = score+2;
    foodGroup.destroyEach();
  }
  
  switch(score){
    case  10: player.scale = 0.12;
             break;
    case  20: player.scale = 0.14;
             break;
    case  30: player.scale = 0.16;
             break;         
    case  40: player.scale = 0.18;
             break;         
    default:  break;         
  }
  
  if(obstaclesGroup.isTouching(monkey)){
    player.scale = 0.2;
  }
  */
   if (ground.x < 0){
      ground.x = ground.width/2;
  }
  
    
     //jump when the space key is pressed
    if(keyDown("space")) {
      monkey.velocityY = -12;
      }
 
   
   //add gravity
    monkey.velocityY = monkey.velocityY + 0.8;
    
    //stop monkey from falling down
   monkey.collide(ground);
  obstacles();
   drawSprites();
  
  
  
  
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500, 50);
  
}

function obstacles() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(400,325,10,40);
    obstacle.velocityX = -10;
    
    
    //generate random obstacles
    //var rand = randomNumber(1,6);
    obstacle.addImage(obstaclesImage);
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.1;
    obstacle.lifetime = 70;
    //add each obstacle to the group
    obstaclesGroup.add(obstacle);
  }
}